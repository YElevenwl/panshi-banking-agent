﻿# 验收 Checklist

> 规则：只有“已实现 + 可运行 + 有测试/审计证据”才能打勾；未实现项明确列在最后。

---

## 一、赛题硬性要求

- [x] 至少 3 个核心场景端到端：智能转账、账单分析、生日跨场景
- [x] 6 场景覆盖矩阵（卡片/订阅/理财为扩展，不承诺端到端）
- [x] 权限分级 GREEN/YELLOW/RED
- [x] 低风险自动、高风险确认、极高风险强验证
- [x] 日累计 ≤1000 元 / >1000 元边界
- [x] 日累计原子预占，防拆单/并发
- [x] 幻觉防护
- [x] 注入防御
- [x] 操作审计（完整决策链）
- [x] 异常熔断
- [x] 沙箱环境（分析沙箱：受限表达式）
- [x] 意图理解（模糊表达/澄清/超范围兜底）
- [x] DAG 任务规划
- [x] 中断
- [x] 回退/补偿
- [x] 人工接管（审批信封 + TOTP）
- [x] 定时任务（转账/生日订单）
- [x] 一条命令启动，无运行时依赖

---

## 二、控制面实现

- [x] LLM 只产出提案，不直接执行
- [x] Orchestrator 路由与状态机
- [x] Policy Gate 确定性裁决
- [x] reason_codes 结构化
- [x] Execution Permit（HMAC + 参数哈希 + nonce + 过期）
- [x] Permit 单次使用/重放拒绝
- [x] 参数篡改拒绝
- [x] 主体绑定/跨用户隔离
- [x] 审批信封（金额/账户/收款人/可逆性/补偿/过期/挑战）
- [x] TOTP 交易挑战
- [x] 四眼原则扩展点（dual_required 标签）
- [x] 全局 kill switch
- [x] 熔断 CLOSED/OPEN/HALF_OPEN
- [x] 只读降级
- [x] 强验证解锁

---

## 三、执行面实现

- [x] Tool Gateway allowlist
- [x] 工具 manifest SHA-256
- [x] 参数 schema 校验
- [x] 结果脱敏
- [x] 工具结果 taint 检测
- [x] 网关+账务双端幂等
- [x] 冻结/捕获/释放
- [x] 转账提交/冲正
- [x] 订单定时/提交/退款
- [x] Mandate 额度/类别/时间窗
- [x] 补偿令牌（release_hold/transfer.reverse/order.cancel/schedule.cancel/mandate.revoke）
- [x] DAG 节点 execute/rollback/on_interrupt
- [x] checkpoint/resume
- [x] Scheduler 到期重评估
- [x] 分析沙箱（无 I/O、白名单变量）

---

## 四、数据面实现

- [x] SQLite WAL
- [x] 复式记账
- [x] 冻结预占
- [x] FactStore
- [x] append-only 审计
- [x] UPDATE/DELETE trigger
- [x] 哈希链
- [x] Merkle anchor（每 100 条）
- [x] trace 时间线
- [x] verify API/CLI
- [x] 审计字段完整（trace/run/node/policy/tool/params_hash/result_digest/permit/approver/hash）

---

## 五、测试与评测

- [x] 单元 + 集成测试 44/44
- [x] 对抗测试 18/18
- [x] 3 核心场景 pass^20
- [x] TCR 100%
- [x] PCR 100%
- [x] TCA 100%
- [x] ABR 100%
- [x] HBR 100%
- [x] PBR 100%
- [x] RRR 100%
- [x] p95 ≤ 200ms（Mock LLM，约 145ms）
- [x] 审计 verify 通过
- [x] 幂等 10 次重试只产生 1 条冻结
- [x] 撤销后余额恢复

---

## 六、交付物

- [x] `README.md` 一键启动/账号/演示路径/对抗测试/审计样例
- [x] `docs/spec.md` 赛题理解 + 架构决策
- [x] `docs/decisions.md` ADR
- [x] `docs/research-log.md` 证据卡片（16 张 + 4 条未验证）
- [x] `docs/technical.md` 技术文档
- [x] `docs/security-self-assessment.md` 安全自评
- [x] `docs/ppt-outline.md` PPT 大纲
- [x] `docs/demo-script.md` 5 分钟视频脚本
- [x] `docs/intro-200.md` 作品简介（183 字）
- [x] `docs/tasks.md` / `docs/checklist.md`
- [x] `scenarios/*.json`
- [x] `eval/report.md` / `eval/report.json`
- [x] `Dockerfile` / `docker-compose.yml`（未本机验证）
- [x] 源代码 + README + 测试用例

---

## 七、交付物完成情况 / 未验证项（必须诚实标注）

- [x] 实际 PPT 文件：`deliverables/PANSHI-答辩.pptx`（16 页，私行审计档案视觉，真实截图）
- [x] PPTX 渲染预览：LibreOffice 26.8 → PDF/PNG 逐页检查；新版账本版 16 页无元素越界，画布 13.333×7.5
- [x] 竞赛统一归档：`submission/` 顶层严格对应 01 技术文档 PDF、02 答辩材料 PPTX、03 源代码与部署材料 ZIP、04 安全自评报告 PDF、05 演示视频 MP4；其他材料在 `_参考材料/`
- [x] 实际演示视频：`deliverables/PANSHI-demo.mp4`（4:02，1080p，中文 TTS，新版视觉）
- [x] 真实模型对照：`eval/report-real.md`（GPT-OSS-20B 公共端点，严格模式）
- [ ] Docker 构建/运行验证（本机无 Docker）
- [ ] GitHub 仓库地址（本机无 git）
- [ ] 真实 FaceID/WebAuthn（TOTP 模拟）
- [ ] gVisor/Firecracker 通用代码沙箱（使用受限表达式沙箱）
- [ ] 生产分布式数据库/消息队列/WORM/HSM
- [ ] MCP 运行时 manifest 热更新校验
- [ ] 双人复核完整 UI（仅标签/扩展点）

---

## 八、答辩前 30 分钟检查

- [ ] Node 版本 ≥24；`node -v`
- [ ] `node src/server.js` 启动
- [ ] 浏览器打开 `http://localhost:8787`
- [ ] 登录 `user_1001`
- [ ] 预跑 800 元转账，确认审批弹窗与 TOTP 面板
- [ ] 预跑注入拦截，确认 `TAINTED_WRITE`
- [ ] 预跑生日流程，确认时间快进/订单提交
- [ ] 点击“校验哈希链”，确认通过
- [ ] 准备离线备份：`eval/report.md`、审计样例、截图
- [ ] 若现场网络不稳，使用 Mock LLM（默认）

---

## 九、签署

- 实现：M0–M4 完成
- 文档：M5 完成
- 待人工：PPT 制作、视频录制、真实模型演示、仓库推送


